import { app, HttpRequest, HttpResponseInit, InvocationContext, output } from "@azure/functions";

// 1. Configura o Output Binding apontando para a sua fila do Service Bus
const serviceBusOutput = output.serviceBusQueue({
    queueName: 'fila-pedidos',
    connection: 'ServiceBusConnection'
});

export async function httpServiceBusPub(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    context.log(`Processando disparo de teste para URL: "${request.url}"`);

    // 2. Mock do JSON definido diretamente no código para o teste simples
    const pedidoMock = {
        PedidoId: 102,
        Cliente: "Professor Teste",
        Total: 450.00,
        DataTeste: new Date().toISOString()
    };

    context.log(`JSON de teste criado: ${JSON.stringify(pedidoMock)}`);

    try {
        // 3. Monta o objeto de mensagem esperado pelo binding do Service Bus
        const mensagem = {
            body: pedidoMock, // O runtime faz o stringify automático para JSON
            contentType: 'application/json',
            messageId: `id-teste-${pedidoMock.PedidoId}-${Date.now()}`
        };

        // 4. Injeta a mensagem na fila usando o extraOutputs
        context.extraOutputs.set(serviceBusOutput, mensagem);

        context.log(`[Sucesso] Mensagem de teste enviada para o Service Bus.`);

        return { 
            status: 200,
            body: `Teste executado com sucesso! JSON enviado: ${JSON.stringify(pedidoMock)}` 
        };

    } catch (error: any) {
        context.log(`[Erro] Falha ao enviar para o Service Bus: ${error.message}`);
        
        return { 
            status: 500, 
            body: `Erro interno no envio: ${error.message}` 
        };
    }
};

// 5. Registra a função HTTP incluindo o extraOutputs na configuração
app.http('httpServiceBusPub', {
    methods: ['GET', 'POST'], // Mantido GET para você testar direto pelo navegador
    authLevel: 'anonymous',
    extraOutputs: [serviceBusOutput], // Obrigatório para o context identificar o binding
    handler: httpServiceBusPub
});


// import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";

// export async function httpServiceBusPub(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
//     context.log(`Http function processed request for url "${request.url}"`);

//     const name = request.query.get('name') || await request.text() || 'world';

//     return { body: `Hello, ${name}!` };
// };

// app.http('httpServiceBusPub', {
//     methods: ['GET', 'POST'],
//     authLevel: 'anonymous',
//     handler: httpServiceBusPub
// });
