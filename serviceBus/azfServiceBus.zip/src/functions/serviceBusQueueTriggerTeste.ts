import { app, InvocationContext } from "@azure/functions";

export async function serviceBusQueueTriggerTeste(message: unknown, context: InvocationContext): Promise<void> {
    context.log('Service bus queue function processed message:', message);
}

app.serviceBusQueue('serviceBusQueueTriggerTeste', {
    connection: 'ServiceBusConnection',
    queueName: 'fila-pedidos',
    handler: serviceBusQueueTriggerTeste
});
